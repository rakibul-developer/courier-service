"use client";

import Packages from "../components/Packages";

export default function PackagesPage() {
  return (
    <main className="container-fluid py-5">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <Packages />
          </div>
        </div>
      </div>
    </main>
  );
}
