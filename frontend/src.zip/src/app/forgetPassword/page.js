import ForgetPassword from "../components/Forgetpassword";

export default function ForgetPasswordPage() {
  return (
    <main className="container-fluid py-5">
      <div className="container">
        <div className="row">
          <div className="col-8 m-auto">
            <ForgetPassword />
          </div>
        </div>
      </div>
    </main>
  );
}
